﻿#pragma once

#include <opencv2/opencv.hpp>
#include <time.h>
#include "ValueI.h"
using namespace cv;  // cv 안써도 됨
using namespace std; //std 안써도 됨

