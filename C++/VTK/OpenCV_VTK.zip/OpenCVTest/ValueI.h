#pragma once


int i = 0; //107, 125 -4